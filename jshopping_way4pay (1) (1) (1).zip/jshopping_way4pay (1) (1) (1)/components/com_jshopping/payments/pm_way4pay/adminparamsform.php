<?php
/**
* @version      4.12.2 05.11.2013
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die();
?>
<div class="col100">
<fieldset class="adminform">
<table class="admintable" width = "100%" >
    <tr>
        <td class="key">
            <?php echo _JSHOP_WAYFORPAY_MERCHANT; ?>
        </td>
        <td>
            <input type = "text" class = "inputbox" name = "pm_params[merchant_account]" size="45" value = "<?php echo $params['merchant_account']?>" />
            <?php echo JHTML::tooltip(_JSHOP_WAYFORPAY_MERCHANT_EXPLAIN);?>
        </td>
    </tr>

    <tr>
        <td class="key">
            <?php echo _JSHOP_WAYFORPAY_SECRET_KEY; ?>
        </td>
        <td>
            <input type = "text" class = "inputbox" name = "pm_params[secret_key]" size="45" value = "<?php echo $params['secret_key']?>" />
            <?php echo JHTML::tooltip(_JSHOP_WAYFORPAY_SECRET_KEY_EXPLAIN);?>
        </td>
    </tr>
    <tr>
        <td class="key">
            <?php echo _JSHOP_WAYFORPAY_STATUS_SUCCESS; ?>
        </td>
        <td>
            <?php
            echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_end_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_end_status']);
            echo " ".JHTML::tooltip(_JSHOP_WAYFORPAY_STATUS_SUCCESS_EXPLAIN);?>
        </td>
    </tr>
    <tr>
        <td class="key">
            <?php echo _JSHOP_WAYFORPAY_STATUS_PENDING; ?>
        </td>
        <td>
            <?php
            echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_pending_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_pending_status']);
            echo " ".JHTML::tooltip(_JSHOP_WAYFORPAY_STATUS_PENDING_EXPLAIN);
            ?>
        </td>
    </tr>
    <tr>
        <td class="key">
            <?php echo _JSHOP_WAYFORPAY_STATUS_FAILD;?>
        </td>
        <td>
            <?php
            echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_failed_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_failed_status']);
            echo " ".JHTML::tooltip(_JSHOP_WAYFORPAY_STATUS_FAILED_EXPLAIN);
            ?>
        </td>
    </tr>
</table>
</fieldset>
</div>
<div class="clr"></div>