INSERT IGNORE INTO `#__jshopping_payment_method`
SET
  `payment_id`            = '11000',
	`payment_code`          = 'way4pay',
	`payment_class`         = 'pm_way4pay',
	`scriptname`            = 'pm_way4pay',
	`payment_publish`       = 1,
	`payment_ordering`      = 0,
  `payment_params`        = "merchant_account=test_merch_n1\nsecret_key=flk3409refn54t54t*FNJRET\ntransaction_end_status=6\ntransaction_pending_status=1\ntransaction_failed_status=3\n",
	`payment_type`          = 2,
	`price`                 = 0.00,
	`price_type`            = 1,
	`tax_id`                = -1,
	`show_descr_in_email`   = 0,
	`name_en-GB`            = 'WayForPay'
;