<?php
/**
 * @version      0.0.1 10.03.2017
 * @author       Dush
 * @package      Jshopping
 * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
 * @license      GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');

class pm_way4pay extends PaymentRoot
{

    /**
     * pm_way4pay constructor.
     */
    function __construct()
    {
        JSFactory::loadExtLanguageFile('pm_way4pay');
    }

    /**
     * @param array $params
     * @param array $pmconfigs
     */
    function showPaymentForm($params, $pmconfigs)
    {
        include(dirname(__FILE__) . "/paymentform.php");
    }

    /**
     * @param $params
     */
    function showAdminFormParams($params)
    {
        $array_params = ['merchant_account', 'secret_key', 'transaction_end_status', 'transaction_pending_status', 'transaction_failed_status'];
        foreach ($array_params as $key) {
            if (!isset($params[$key])) $params[$key] = '';
        }
        if (!isset($params['use_ssl'])) $params['use_ssl'] = 0;
        if (!isset($params['address_override'])) $params['address_override'] = 0;

        $ssl_options = array();
        $ssl_options[] = JHTML::_('select.option', 4, 'TLSv1_0', 'id', 'name');
        $ssl_options[] = JHTML::_('select.option', 5, 'TLSv1_1', 'id', 'name');
        $ssl_options[] = JHTML::_('select.option', 6, 'TLSv1_2', 'id', 'name');

        $orders = JSFactory::getModel('orders', 'JshoppingModel'); //admin model
        include(dirname(__FILE__) . "/adminparamsform.php");
    }

    /**
     * @param array $pmconfigs
     * @param object $order
     * @param string $act
     * @return array|null
     * @throws Exception
     */
    function checkTransaction($pmconfigs, $order, $act)
    {
        $json = file_get_contents('php://input');
        $path = dirname(__FILE__) . "/WayForPay.cls.php";
        include_once($path);

        $w4p = new WayForPay();
        $w4p->setSecretKey($pmconfigs["secret_key"]);

        $serviceUrl = false;

        if (!empty($json)) {
            $post = json_decode($json, true);
            $response_sign = $w4p->getResponseSignature($post);
            $serviceUrl = true;
        } else {
            $post = JFactory::getApplication()->input->post->getArray();
            $response_sign = $w4p->getResponseSignature($post);
        }
        $request_sign = $post['merchantSignature'];

        if ($response_sign != $request_sign) return null;

        $transactionStatus = !empty($post['transactionStatus'])?$post['transactionStatus']:'';

        switch ($transactionStatus) {
            case 'Approved' : //status  OK
                $order->store();
                saveToLog("payment.log", "Status approved. Order ID " . $order->order_id . ".");
                $answer = [1, 'Status Approved. Order ID ' . $order->order_id, '', 'Approved'];
                break;
            case 'Declined' : //status Decline
                $order->store();
                saveToLog("payment.log", "Status declined. Order ID " . $order->order_id . ". Reason: " . $post['reason']);
                $answer = [3, 'Status Failed. Order ID ' . $order->order_id . "Reason: " . $post['reason'], '', 'Failed'];
                break;
            default :
                $order->store();
                saveToLog("payment.log", "Status pending. Order ID " . $order->order_id . ".");
                $answer = [2, 'Status Pending. Order ID ' . $order->order_id, '', 'Pending'];
        }

        if($serviceUrl){
            echo $w4p->getAnswerToGateWay($post);
            die;
        }

        return $answer;
    }

    function showEndForm($pmconfigs, $order)
    {
        $pm_method = $this->getPmMethod();

        $path = dirname(__FILE__) . "/WayForPay.cls.php";
        include_once($path);

        $w4p = new WayForPay();
        $w4p->setSecretKey($pmconfigs["secret_key"]);
        $uri = JURI::getInstance();
        $liveurlhost = $uri->toString(array("scheme", 'host', 'port'));

        $return_url = JURI::root()."index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=" . $pm_method->payment_class;
        $notify_url = JURI::root()."index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=".$pm_method->payment_class."&no_lang=1";
        list($lang,) = explode('-', JFactory::getLanguage()->getTag());

        $formFields = [
            'merchantAccount' => $pmconfigs["merchant_account"],
            'merchantAuthType' => 'simpleSignature',
            'merchantDomainName' => $_SERVER['HTTP_HOST'],
            'merchantTransactionSecureType' => 'AUTO',
            'language' => strtoupper($lang),
            'returnUrl' => $return_url,
            'serviceUrl' => $notify_url,
            'orderReference' => $order->order_id . WayForPay::ORDER_SEPARATOR . time(),
            'orderDate' => strtotime($order->order_date),
            'amount' => number_format($order->order_total, 2, '.', ''),
            'currency' => $order->currency_code_iso,
        ];
        $cart = JSFactory::getModel('cart', 'jshop');
        $cart->load();

        $productNames = [];
        $productQty = [];
        $productPrices = [];
        foreach ($cart->products as $item) {
            $productNames[] = $item['product_name'];
            $productPrices[] = $item['price'];
            $productQty[] = $item['quantity'];
        }

        $formFields['productName'] = $productNames;
        $formFields['productPrice'] = $productPrices;
        $formFields['productCount'] = $productQty;

        /**
         * Check phone
         */
        if (!empty($order->phone)) {
            $phone = $order->phone;
        } else {
            $phone = $order->mobil_phone;
        }
        $phone = str_replace(['+', ' ', '(', ')'], ['', '', '', ''], $phone);
        if (strlen($phone) == 10) {
            $phone = '38' . $phone;
        } elseif (strlen($phone) == 11) {
            $phone = '3' . $phone;
        }

        $formFields['clientFirstName'] = $order->f_name;
        $formFields['clientLastName'] = $order->l_name;
        $formFields['clientEmail'] = $order->email;
        $formFields['clientPhone'] = $phone;
        $formFields['clientCity'] = $order->city;
        $formFields['clientAddress'] = $order->street . ' ' . $order->apartment;

        $formFields['merchantSignature'] = $w4p->getRequestSignature($formFields);

        $wayforpayArgsArray = [];
        foreach ($formFields as $key => $value) {
            if (is_array($value)) {
                foreach ($value as $v) {

                    $wayforpayArgsArray[] = "<input type='hidden' name='{$key}[]' value='".addslashes($v)."'/>";
                }
            } else {
                $wayforpayArgsArray[] = "<input type='hidden' name='$key' value='".addslashes($value)."'/>";
            }
        }
        ?>
        <form action="<?php print Wayforpay::URL; ?>" method="post" id="wayforpay_payment_form">
            <?php print implode('', $wayforpayArgsArray) ?>
        </form>
        <script type="text/javascript">
            function submitWayForPayForm() {
                document.getElementById('wayforpay_payment_form').submit();
            }
            setTimeout(submitWayForPayForm, 200);
        </script>
        <?php
        die();
    }

    /**
     * @param $pmconfigs
     * @return array
     * @throws Exception
     */
    function getUrlParams($pmconfigs)
    {
        $path = dirname(__FILE__) . "/WayForPay.cls.php";
        include_once($path);
        $params = array();
        $post = JFactory::getApplication()->input->post->getArray();
        $params['orderReference'] = $post['orderReference'];
        $params['transactionStatus'] = $post['transactionStatus'];
        $params['reason'] = $post['reason'];
        $params['reasonCode'] = $post['reasonCode'];
        list($params['order_id'],) = explode(WayForPay::ORDER_SEPARATOR, $params['orderReference']);
        $params['hash'] = "";
        $params['checkHash'] = 0;
        $params['checkReturnParams'] = 1;
        return $params;
    }
}
