<?php

defined('_JEXEC') or die('Restricted access');

define(_JSHOP_WAYFORPAY,"Плагин платежной системы WayForPay");
define(_JSHOP_WAYFORPAY_MERCHANT, "ID мерчанта");
define(_JSHOP_WAYFORPAY_MERCHANT_EXPLAIN, "Идентификатор мерчанта");
define(_JSHOP_WAYFORPAY_SECRET_KEY, "Секретный ключ");
define(_JSHOP_WAYFORPAY_SECRET_KEY_EXPLAIN, "Cекретный ключ вашего мерчанта");
define(_JSHOP_WAYFORPAY_CURRENCY, "Валюта мерчанта");
define(_JSHOP_WAYFORPAY_CURRENCY_EXPLAIN, "Валюта, которая используется в настройках вашего мерчанта");
define(_JSHOP_WAYFORPAY_LANGUAGE, "Язык страницы оплаты WayForPay");
define(_JSHOP_WAYFORPAY_LANGUAGE_EXPLAIN, "Доступны ( RU, EN, UA )");

define(_JSHOP_WAYFORPAY_COUNTRY, "Страна подключения WayForPay");
define(_JSHOP_WAYFORPAY_COUNTRY_EXPLAIN, "Украина или Россия");

define(_JSHOP_WAYFORPAY_STATUS_PENDING, "Статус платежа после создания");
define(_JSHOP_WAYFORPAY_STATUS_PENDING_EXPLAIN, "Статус, который будет у заказа после создания");
define(_JSHOP_WAYFORPAY_STATUS_SUCCESS, "Статус платежа после оплаты");
define(_JSHOP_WAYFORPAY_STATUS_SUCCESS_EXPLAIN, "Статус, который будет у заказа после успешной оплаты");
define(_JSHOP_WAYFORPAY_STATUS_FAILD, "Статус платежа после ошибки оплаты");
define(_JSHOP_WAYFORPAY_STATUS_FAILD_EXPLAIN, "Статус, который будет у заказа после ошибки оплаты");
define(_JSHOP_WAYFORPAY_SYSTEM_CURRENCY, "Использовать для оплаты валюту магазина?");
define(_JSHOP_WAYFORPAY_SYSTEM_CURRENCY_EXPLAIN, " 'Да'  - если нужно использовать валюту магазина");

define(_JSHOP_WAYFORPAY_MIN_AMOUNT, "Минимальная сумма");
define(_JSHOP_WAYFORPAY_MIN_AMOUNT_EXPLAIN, "Минимальная сумма заказа для оссущетвления даннаго платежа");
define(_JSHOP_WAYFORPAY_COUNTRIES, "Страны");
define(_JSHOP_WAYFORPAY_COUNTRIES_EXPLAIN, "Страны для которых доступен вид платежа");
define(_JSHOP_WAYFORPAY_CURRENCY, "Валюта");
define(_JSHOP_WAYFORPAY_CURRENCY_EXPLAIN, "Валюта платежа");
define(_JSHOP_WAYFORPAY_COST_PERCENT_TOTAL, "Комиссия в процентах");
define(_JSHOP_WAYFORPAY_COST_PERCENT_TOTAL_EXPLAIN, "Комиссия в процентах");
define(_JSHOP_WAYFORPAY_COST_PER_TRANSACTION, "Комиссия");
define(_JSHOP_WAYFORPAY_COST_PER_TRANSACTION_EXPLAIN, "Комиссия");
define(_JSHOP_WAYFORPAY_TAX, "Налог");
define(_JSHOP_WAYFORPAY_TAX_EXPLAIN, "Налог");
define(_JSHOP_WAYFORPAY_WAYFORPAY, "Плагин стандартной оплаты");
define(_JSHOP_WAYFORPAY_PAYMENT_INFO, "Способ оплаты");
define(_JSHOP_WAYFORPAY_ORDER_NUMBER, "Номер заказа");
define(_JSHOP_WAYFORPAY_AMOUNT, "Итог");
define(_JSHOP_WAYFORPAY_PAY, "Оплатить");
